Define variables
root of API
1. nqapp.nurulquran.com
