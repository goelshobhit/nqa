export { default } from "./Catergory";
