export const version = "1.2.01";
export const domain = "https://nqapp.nurulquran.com"
